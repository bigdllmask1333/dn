-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : domain_name
--
-- Part : #1
-- Date : 2018-05-16 16:09:09
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `dn_admin_access`
-- -----------------------------
DROP TABLE IF EXISTS `dn_admin_access`;
CREATE TABLE `dn_admin_access` (
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `group` varchar(16) NOT NULL DEFAULT '' COMMENT '权限分组标识',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '授权节点id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='统一授权表';

